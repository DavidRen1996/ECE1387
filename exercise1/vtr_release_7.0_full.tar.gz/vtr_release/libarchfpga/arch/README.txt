This directory contains sample architecture files that are used in testing
libarchfpga. In addition, the architecture files in this directory are used by
the regression testing facilities of Odin II.

Please be sure to retain sample_arch.xml and update it with any changes that
are made to the libvpr library.

Ken Kent
ken@unb.ca
06.18.2009

