
void activity_estimation(char *input_filename, char *output_filename, int lut_size, netlist_t *LUT_netlist, netlist_t *CLUSTER_netlist);
