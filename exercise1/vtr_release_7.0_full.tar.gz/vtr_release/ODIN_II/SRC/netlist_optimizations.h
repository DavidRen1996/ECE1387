// PROTOTYPES
void netlist_optimizations_top(netlist_t *netlist);
