

void optimizations_on_AST(ast_node_t *top);
info_ast_visit_t *constantFold(ast_node_t *node);
