#ifndef READ_BLIF_H
#define READ_BLIF_H

void read_blif(char* blif_file);


#endif

