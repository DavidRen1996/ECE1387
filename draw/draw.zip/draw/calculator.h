#pragma once
#include <sstream>
#include <map>
#include <vector>
#include "extern.h"
//#include "branching.h"
using namespace std;
class calculator
{

public:
	calculator();
	~calculator();
	int cost_increase(vector<int>x, int n);
	int getc_cost(int b1, int b2);
	//int slot_overflow(vector<int>x, int n);//replaced by adding counting number for 1,2,3 at the end of vector 
};

