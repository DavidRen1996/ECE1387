#pragma once
#include "graphics.h"
#include <map>
#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <math.h>
#include "extern.h"
using namespace std;
class draw_graph
{
	
public:
	draw_graph();
	~draw_graph();
	void draw_depth(map<int, vector<int>>x1);
	void draw_lbf(map<int, vector<int>>x2);
};

