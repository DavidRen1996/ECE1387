//s#include "stdafx.h"
#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <map>
#include "file_extract.h"
#include "branching.h"
using namespace std;
extern content file_reclaim;
extern map<int, vector<int>>order;
extern vector<int>branching_o;