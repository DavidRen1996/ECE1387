//#include "stdafx.h"
#include "extern.h"
file_extract a;
branching b;
content file_reclaim = a.extraction();
map<int, vector<int>>order = a.get_connection();
vector<int>branching_o = b.initial_partition();