#include "stdafx.h"
#include "recurs.h"
#include <iostream>
using namespace std;
extract c;
//int van = 3;
//vector<int>b(8);
vec_rec rec_val = c.recv();
vector<int> nget=c.get_net();
extern vector<double>fget=c.fixed();
extern vector<vector<int>>ad = c.advanced_return();
	//cout << van;


	