//#include "stdafx.h"
#include <vector>
#include "extract.h"
using namespace std;
//extern vector<int>b;
//extern int van;
extern vector<int> nget;
extern vector<double>fget;
extern vec_rec rec_val;
extern vector<vector<int>>ad;
//void sample();