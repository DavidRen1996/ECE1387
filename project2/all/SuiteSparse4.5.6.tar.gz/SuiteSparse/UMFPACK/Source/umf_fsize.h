/* -------------------------------------------------------------------------- */
/* Copyright (c) 2005-2012 by Timothy A. Davis, http://www.suitesparse.com.   */
/* All Rights Reserved.  See ../Doc/License.txt.txt for License.              */
/* -------------------------------------------------------------------------- */

GLOBAL void UMF_fsize
(
    Int nn,
    Int MaxFsize [ ],
    Int Fnrows [ ],
    Int Fncols [ ],
    Int Parent [ ],
    Int Npiv [ ]
) ;
