truncated with 5th Harwell/Boeing line
             3             1             1             1
iua                        4             4            16             0
(26I3)          (40I2)          (26I3)              
F
